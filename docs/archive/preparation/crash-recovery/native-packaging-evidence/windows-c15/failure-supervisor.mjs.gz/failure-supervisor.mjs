/** Sequential Off/On comparisons. Explicit paths; no installs, network calls or real profiles. */
import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { spawn, execFileSync } from "node:child_process";
import { once } from "node:events";
import { setTimeout as delay } from "node:timers/promises";
import { createHash, randomUUID } from "node:crypto";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";
const [electronDirectory, outputDirectory, schedule, privateParent] = process.argv.slice(2);
assert.equal(process.platform, "win32");
assert.ok(["failure", "stall"].includes(schedule), "one explicit schedule per invocation");
assert.ok(privateParent && path.isAbsolute(privateParent), "explicit previously accepted disposable parent");
const repo = path.resolve(fileURLToPath(new URL("../../../..", import.meta.url)));
const electron = path.resolve(electronDirectory),
  output = path.resolve(outputDirectory);
fs.mkdirSync(output, { recursive: true });
assert.equal(fs.existsSync(path.join(output, schedule + "-results.json")), false, "never replace an attempt");
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const pin = "7d7d503317c9bc2ae5bb3e3ec972e59f28a2e849";
assert.equal(execFileSync("git", ["rev-parse", "HEAD"], { cwd: repo, encoding: "utf8" }).trim(), pin);
assert.equal(
  execFileSync("git", ["diff", "5fac1a05a56152861ca08168da0b052f56e8cbae", "HEAD", "--", "packages"], { cwd: repo })
    .length,
  0,
);
const compiled = path.join(repo, "packages/app/dist/main/diagnostics");
assert.equal(
  sha(fs.readFileSync(path.join(compiled, "recovery-controller.js"))),
  "a62b48551a88eb4b1eb4be9f7dd55106c46df1f0b2330b8eda1d46bd0226fd4c",
);
assert.equal(
  sha(fs.readFileSync(path.join(repo, "packages/cli/dist/main.js"))),
  "74ec189a007b6ec9cebdb2dccbbc6318298f9c8abffa5a21ef414cfe32284898",
);
const backend = createRequire(import.meta.url)(
  path.join(electron, "resources/native/diagnostics/win32-x64/diagnostics_storage.node"),
);
const { createHandleRelativeStorage } = await import(pathToFileURL(path.join(compiled, "native-storage.js")).href);
const { fileStores } = await import(pathToURL(path.join(repo, "packages/store/dist/index.js")));
const { parseFrontMatter } = await import(pathToURL(path.join(repo, "packages/core/dist/index.js")));
function pathToURL(p) {
  return pathToFileURL(p).href;
}
const fixtureParent = fs.realpathSync(privateParent);
assert.notEqual(fixtureParent, path.parse(fixtureParent).root);
const root = path.join(fixtureParent, "orca-c15-" + randomUUID());
const owned = new Set();
const result = {
  schema: 1,
  schedule,
  sourceCommit: pin,
  productionSource: "5fac1a05a56152861ca08168da0b052f56e8cbae",
  productionEnabled: false,
  macHeld: true,
  timingDeferred: true,
  attempts: 1,
  runs: [],
  method:
    "One failure or stall schedule compares sequential Off/On CLI demos; 20 fixed fault cells inside On, no performance retry. Synthetic seams with real Windows x64 Electron/native disk, DPAPI and clock.",
};
function launch(command, args, options) {
  const child = spawn(command, args, { windowsHide: true, stdio: ["ignore", "pipe", "pipe"], ...options });
  owned.add(child);
  child.once("exit", () => owned.delete(child));
  let bytes = 0;
  child.stdout.on("data", (data) => {
    bytes += data.length;
  });
  child.stderr.on("data", (data) => {
    bytes += data.length;
  });
  child.outputBytes = () => bytes;
  return child;
}
async function bounded(work, ms, code) {
  let timeout;
  try {
    return await Promise.race([
      work,
      new Promise((_, reject) => {
        timeout = setTimeout(() => reject(Error(code)), ms);
      }),
    ]);
  } finally {
    clearTimeout(timeout);
  }
}
async function stop(child) {
  if (child.exitCode !== null) return;
  const exited = once(child, "exit");
  execFileSync("C:/Windows/System32/taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], {
    windowsHide: true,
    stdio: "ignore",
    timeout: 5000,
  });
  await bounded(exited, 5000, "owned-exit-unconfirmed");
}
async function file(p, child, ms) {
  const end = performance.now() + ms;
  while (!fs.existsSync(p)) {
    if (child.exitCode !== null) throw Error("child-no-receipt");
    if (performance.now() > end) throw Error("receipt-deadline");
    await delay(10);
  }
}
function normalize(v) {
  if (Array.isArray(v)) return v.map(normalize);
  if (v && typeof v === "object")
    return Object.fromEntries(
      Object.entries(v)
        .filter(
          ([k]) =>
            ![
              "id",
              "requestId",
              "runId",
              "stepRunId",
              "createdAt",
              "updatedAt",
              "timestamp",
              "producedBy",
              "parentId",
            ].includes(k),
        )
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([k, x]) => [k, normalize(x)]),
    );
  if (typeof v === "string")
    return v
      .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, "<generated-id>")
      .replace(
        /\b(req|wi|wf|run|step|art|evt|sess|orc|tpl|host|hi|plan|dep|risk|dec|pev)_[0-9A-HJKMNP-TV-Z]{26}\b/g,
        "$1_<generated-id>",
      )
      .replace(/\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z/g, "<generated-time>");
  return v;
}
async function semanticOracle(directory) {
  const stores = fileStores(path.join(directory, ".orca"));
  const inventory = await stores.artifacts.list(),
    semantic = [];
  for (const artifact of inventory) {
    const parsed = parseFrontMatter(await stores.artifacts.content(artifact.id));
    semantic.push({
      kind: artifact.kind,
      name: normalize(artifact.name),
      data: normalize(parsed.data),
      body: normalize(parsed.body),
    });
  }
  semantic.sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return {
    artifactCount: inventory.length,
    semanticSignature: sha(JSON.stringify(semantic)),
    semanticByKind: semantic.map((x) => ({ kind: x.kind, name: x.name, sha256: sha(JSON.stringify(x)) })),
    workItems: (await stores.workItems.list())
      .map((x) => ({ slug: x.slug, status: x.status }))
      .sort((a, b) => a.slug.localeCompare(b.slug)),
    normalization:
      "Reused successful-pair oracle: generated identities/provenance/times removed, semantic front matter/prose/kind/name/multiplicity retained. Not complete execution graph equivalence.",
  };
}
async function run(mode) {
  const row = { mode, completed: false };
  result.runs.push(row);
  const base = path.join(root, mode);
  const storage = createHandleRelativeStorage(base, backend);
  assert.equal(await storage.native.verifyRoot(base), true);
  await storage.close();
  fs.writeFileSync(path.join(base, "sentinel"), "synthetic unrelated file");
  const request = path.join(base, "request.json");
  fs.writeFileSync(request, JSON.stringify({ base, compiled, mode, schedule }));
  const env = {
    SystemRoot: "C:/Windows",
    WINDIR: "C:/Windows",
    PATH: "C:/Windows/System32",
    TEMP: base,
    TMP: base,
    APPDATA: path.join(base, "appdata"),
    LOCALAPPDATA: path.join(base, "localappdata"),
    USERPROFILE: base,
  };
  for (const name of ["APPDATA", "LOCALAPPDATA"]) fs.mkdirSync(env[name]);
  process.stdout.write(JSON.stringify({ schedule, phase: "launch", mode }) + "\n");
  const diagnostic = launch(
    path.join(electron, "electron.exe"),
    [fileURLToPath(new URL("windows-c15-child.cjs", import.meta.url)), request],
    { env },
  );
  const diagnosticExit = once(diagnostic, "exit");
  diagnosticExit.catch(() => {});
  await file(path.join(base, "execution.start"), diagnostic, 5000);
  const execution = path.join(base, "execution");
  fs.mkdirSync(execution);
  const start = performance.now();
  const cli = launch(
    process.execPath,
    [path.join(repo, "packages/cli/dist/main.js"), "demo", "--dir", execution, "--keep", "--quiet"],
    { cwd: execution, env: { ...env, PATH: process.env.PATH } },
  );
  const cliExit = once(cli, "exit");
  fs.writeFileSync(path.join(base, "execution.running"), "running");
  const done = await bounded(cliExit, 50000, "cli-deadline");
  row.executionElapsedMs = performance.now() - start;
  row.executionExitCode = done[0];
  row.outputBytes = cli.outputBytes();
  fs.writeFileSync(path.join(base, "execution.done"), "done");
  await file(path.join(base, "result.json"), diagnostic, 10000);
  row.diagnosticExitCode = (await bounded(diagnosticExit, 5000, "diagnostic-exit-deadline"))[0];
  row.diagnostic = JSON.parse(fs.readFileSync(path.join(base, "result.json"), "utf8"));
  row.executionOracle = await semanticOracle(execution);
  row.sentinelUnchanged = fs.readFileSync(path.join(base, "sentinel"), "utf8") === "synthetic unrelated file";
  row.completed = true;
  fs.writeFileSync(path.join(output, schedule + "-" + mode + ".json"), JSON.stringify(row, null, 2) + "\n");
  assert.equal(row.executionExitCode, 0);
  assert.equal(row.diagnosticExitCode, 0);
  assert.equal(row.diagnostic.ok, true);
  assert.equal(row.sentinelUnchanged, true);
  assert.equal(row.executionOracle.artifactCount, 29);
  assert.ok(row.diagnostic.cells.every((x) => mode === "off" || x.faultObserved));
  // Each seam must have been reached while execution was alive; campaign may finish after the CLI.
  row.allFaultsEnteredDuringExecution =
    mode === "off" || row.diagnostic.cells.every((x) => x.enteredMs < row.executionElapsedMs);
  assert.equal(row.allFaultsEnteredDuringExecution, true);
}
try {
  const rootStorage = createHandleRelativeStorage(root, backend);
  try {
    assert.equal(await rootStorage.native.verifyRoot(root), true, "native private fixture root");
  } finally {
    await rootStorage.close();
  }
  await run("off");
  await run("on");
  const [off, on] = result.runs;
  result.semanticEqual = off.executionOracle.semanticSignature === on.executionOracle.semanticSignature;
  result.workEqual = JSON.stringify(off.executionOracle.workItems) === JSON.stringify(on.executionOracle.workItems);
  assert.equal(result.semanticEqual, true);
  assert.equal(result.workEqual, true);
  result.correctnessPass = true;
  result.memoryPass = result.runs.every((x) => x.diagnostic.memory.managedPass && x.diagnostic.memory.binaryPass);
} catch (error) {
  result.correctnessPass = false;
  result.failureCode = error.message;
} finally {
  // Retain partial receipts even on failure, before disposing an owned profile.
  for (const mode of ["off", "on"]) {
    const receipt = path.join(root, mode, "result.json");
    if (fs.existsSync(receipt)) fs.copyFileSync(receipt, path.join(output, schedule + "-" + mode + "-receipt.json"));
  }
  result.allOwnedExitsConfirmed = true;
  for (const child of owned)
    try {
      await stop(child);
    } catch {
      result.allOwnedExitsConfirmed = false;
    }
  result.allOwnedExitsConfirmed &&= owned.size === 0;
  if (result.allOwnedExitsConfirmed && fs.existsSync(root)) {
    const resolved = fs.realpathSync(root);
    assert.equal(path.dirname(resolved), fixtureParent);
    assert.ok(path.basename(resolved).startsWith("orca-c15-"));
    fs.rmSync(resolved, { recursive: true, force: true });
    result.disposableStateRemoved = !fs.existsSync(resolved);
  }
  fs.writeFileSync(path.join(output, schedule + "-results.json"), JSON.stringify(result, null, 2) + "\n");
  process.stdout.write(
    JSON.stringify({
      schedule,
      correctnessPass: result.correctnessPass,
      memoryPass: result.memoryPass,
      failureCode: result.failureCode,
      allOwnedExitsConfirmed: result.allOwnedExitsConfirmed,
      disposableStateRemoved: result.disposableStateRemoved,
    }) + "\n",
  );
  if (!result.correctnessPass || !result.memoryPass || !result.allOwnedExitsConfirmed) process.exitCode = 1;
}
