const fs = require('node:fs');
const path = require('node:path');
const {createRequire} = require('node:module');
const {fork} = require('node:child_process');
const {performance} = require('node:perf_hooks');
const root = '/workspace/orca-issue510-retry';
const r = createRequire(path.join(root,'package.json'));
const es = createRequire(r.resolve('tsx/package.json'))('esbuild');
const entry = 'packages/engine/test/admission-retry-multiprocess/worker.ts';
const out = path.join(root, '.orca/probe');
fs.rmSync(out,{recursive:true,force:true});
fs.mkdirSync(out,{recursive:true});
const begin = performance.now();
const graph = es.buildSync({absWorkingDir:root,entryPoints:[entry],bundle:true,treeShaking:false,packages:'external',platform:'node',format:'esm',write:false,metafile:true,tsconfig:path.join(root,'tsconfig.json')}).metafile;
es.buildSync({absWorkingDir:root,entryPoints:Object.keys(graph.inputs),outbase:root,outdir:out,bundle:false,platform:'node',format:'esm',target:`node${process.versions.node}`,keepNames:true,sourcemap:'inline',tsconfig:path.join(root,'tsconfig.json')});
fs.writeFileSync(path.join(out,'package.json'),JSON.stringify({type:'module'}));
const pkgs = [...new Set(Object.keys(graph.inputs).map(x=>x.split('/')[1]))];
for(const pkg of pkgs){
 const manifest = JSON.parse(fs.readFileSync(path.join(root,'packages',pkg,'package.json')));
 const exports = Object.fromEntries(Object.entries(manifest.exports).map(([k,v])=>[k,v.import.replace('./dist/','./src/')]));
 fs.writeFileSync(path.join(out,'packages',pkg,'package.json'),JSON.stringify({type:'module',name:manifest.name,exports}));
 for(const [dep,version] of Object.entries(manifest.dependencies||{})) {
   if(version==='workspace:*') continue;
   const link = path.join(out,'packages',pkg,'node_modules',dep);
   fs.mkdirSync(path.dirname(link),{recursive:true});
   fs.symlinkSync(fs.realpathSync(path.join(root,'packages',pkg,'node_modules',dep)),link,'junction');
 }
 const link = path.join(out,'node_modules','@orca',pkg);
 fs.mkdirSync(path.dirname(link),{recursive:true});
 fs.symlinkSync(path.join(out,'packages',pkg),link,'junction');
}
const compileMs = performance.now()-begin;
async function sample(variant,i){
 const dir = fs.mkdtempSync('/workspace/scratch/issue510-retry/state-');
 const start=performance.now();
 const child=fork(variant==='before'?path.join(root,entry):path.join(out,entry.replace(/\.ts$/,'.js')),[dir,'request','none','normal'],{execArgv:variant==='before'?['--import',path.join(path.dirname(r.resolve('tsx/package.json')), 'dist/loader.mjs')]:[],stdio:['ignore','ignore','pipe','ipc']});
 let stderr='';child.stderr.on('data',x=>stderr+=x);
 return await new Promise((resolve,reject)=>{
  let readyMs;
  const timer=setTimeout(()=>child.kill('SIGKILL'),15000);
  child.on('message',message=>{if(message.type==='ready'){readyMs=performance.now()-start;child.kill('SIGKILL');}if(message.type==='error')stderr+=JSON.stringify(message.data)});
  child.on('error',reject);
  child.on('close',(code,signal)=>{clearTimeout(timer);fs.rmSync(dir,{recursive:true,force:true});resolve({variant,i,pid:child.pid,readyMs,closeMs:performance.now()-start,code,signal,stderr});});
 });
}
(async()=>{
 const rows=[];
 for(let i=0;i<6;i++)for(const v of i%2?['after','before']:['before','after'])rows.push(await sample(v,i));
 fs.writeFileSync('/workspace/scratch/issue510-retry/feasibility.json',JSON.stringify({node:process.version,compileMs,files:Object.keys(graph.inputs).length,rows},null,2));
 console.log(JSON.stringify({compileMs,files:Object.keys(graph.inputs).length,rows},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
